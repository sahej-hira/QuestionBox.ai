import React from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';

const Dashboard = () => {
    return(
        <div>
            <Header/>
            <Sidebar/>
            <h1>What would you like to do today?</h1>
            <button classname="bg-[#e6d9f7] text-[#333]">Generate question papers</button>
            <button classname="bg-[#e6d9f7] text-[#333]">Create assessment activities</button>


            <h1>Recents:</h1>
            <div classname="bg-[grey]"></div>
        </div>
    )
}

export default Dashboard;