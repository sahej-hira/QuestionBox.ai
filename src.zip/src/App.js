import './App.css';
import Dashboard from './pages/dashboard';

function App() {
  
  return (
    <div className="flex h-screen ">
        <div className="flex-1 flex flex-col">
          
            <div className="dashboard mx-auto w-1/2">
              <Dashboard />
            </div>
        </div>
    </div>
  );
}



export default App;
