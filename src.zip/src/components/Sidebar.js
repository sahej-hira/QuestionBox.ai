import React from 'react';
import 'tailwindcss/tailwind.css'; // Ensure Tailwind CSS is imported

const Sidebar = () => {
  return (
    <div className="bg-[#e6d9f7] text-[#333] w-[250px] p-[0px_10px_5px_13px] flex flex-col h-screen text-left">
      <div className="text-[#6a0dad] text-[1.5rem] font-bold mb-[10px]">
        <h2>QuestionBox.ai</h2>
      </div>
      <div className="mb-[auto]">
        <div className="mt-[10px] mx-[7px]">
          <ul className="space-y-1">
            <li className="text-[1.2rem] cursor-pointer hover:text-[#6a0dad]">Dashboard</li>
            <li className="text-[1.2rem] cursor-pointer hover:text-[#6a0dad]">Question Paper</li>
            <li className="text-[1.2rem] cursor-pointer hover:text-[#6a0dad]">Assessment Activities</li>
            <li className="text-[1.2rem] cursor-pointer hover:text-[#6a0dad]">About</li>
          </ul>
        </div>
      </div>
      <div className="bg-[#c3a6e7] rounded-[10px] p-[11px]">
        <h4 className="text-[1rem] font-bold mx-[7px]">Personal account</h4>
        <p className="text-[0.9rem] mx-[7px]">User's name</p>
        <h4 className="text-[1rem] font-bold mx-[7px]">Account type:</h4> 
        <p className="text-[0.9rem] mx-[7px]">Teacher/student</p>
        <h4 className="text-[1rem] font-bold mx-[7px]">Active coursework:</h4>
        <p className="text-[0.9rem] mx-[7px]">#number</p>
      </div>
    </div>
  );
}

export default Sidebar;

