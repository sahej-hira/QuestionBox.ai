import React from 'react';
import 'tailwindcss/tailwind.css';

const Header = () => {
    return(
        <div>
            <div className="bg-[#e6d9f7] text-[#333] w-[100%] h-[10vh] p-[8px_10px_8px_13px] flex flex-row justify-end">
                this is the header;

            </div>
        </div>
    )
}

export default Header;